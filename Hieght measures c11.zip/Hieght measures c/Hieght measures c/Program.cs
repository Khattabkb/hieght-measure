﻿// This program takes a person's height in centimeters as input and classifies them based on their height.
// Get the person's height in centimeters.
System.Console.WriteLine("Enter your height in centimeters:");
double height = double.Parse(System.Console.ReadLine());
// Classify the person based on their height.
string heightClassification;
if (height < 135)
{
    heightClassification = "Dwarf";
}
else if (height >= 135 && height < 150)
{
    heightClassification = "Short";
}
else if (height >= 150 && height < 165)
{
    heightClassification = "Average";
}
else if (height >= 165 && height < 180)
{
    heightClassification = "Tall";
}
else
{
    heightClassification = "Very tall";
}
// Print the person's height classification.
System.Console.WriteLine($"The person is {heightClassification}.");

